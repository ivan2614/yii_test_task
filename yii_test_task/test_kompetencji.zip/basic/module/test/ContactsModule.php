<?php

namespace app\module\test;

class ContactsModule extends \yii\base\Module
{
    public $controllerNamespace = 'app\module\test\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
