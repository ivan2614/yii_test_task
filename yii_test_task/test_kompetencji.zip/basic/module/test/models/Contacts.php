<?php

namespace app\module\test\models;

use Yii;

/**
 * This is the model class for table "contacts".
 *
 * @property integer $id_contact
 * @property string $fname
 * @property string $lname
 * @property string $phone
 * @property string $email
 * @property string $address
 * @property string $city
 * @property string $zip
 * @property integer $is_friend
 */
class Contacts extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'contacts';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['is_friend', 'zip'], 'string', 'max' => 5],
            [['fname', 'lname', 'phone', 'email', 'address', 'city'], 'string', 'max' => 50],
            ['email', 'email'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            //'id_contact' => 'Id',
            'fname' => 'Name',
            'lname' => 'Last Name',
            'phone' => 'Phone',
            'email' => 'Email',
            'address' => 'Address',
            'city' => 'City',
            'zip' => 'Zip',
            'is_friend' => 'Friend?',
        ];
    }
    
            //My addition
    /*
	  * function to change 1/2 in is_friend field to yes/no     
     */
    public function getFriendis() {
	
		return $this->hasOne (Friendis::className(), ['is_friend_id'=>'is_friend']);   
    }    
}
