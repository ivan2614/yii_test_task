<?php

namespace app\module\test\models;

use Yii;

/**
 * This is the model class for table "friendis".
 *
 * @property integer $is_friend_id
 * @property string $friend_is
 */
class Friendis extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'friendis';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['is_friend_id'], 'required'],
            [['is_friend_id'], 'string'],
            [['friend_is'], 'string', 'max' => 5]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'is_friend_id' => 'Is Friend ID',
            'friend_is' => 'Friend Is',
        ];
    }
    
}
