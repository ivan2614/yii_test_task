<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\module\test\models\FriendisSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Friendis';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="friendis-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Friendis', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'is_friend_id',
            'friend_is',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
