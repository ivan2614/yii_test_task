<?php
/* @var $this yii\web\View */
$this->title = 'My Yii Application';
?>
<div class="site-index">


    <div class="jumbotron">
        <h1>Contacts Book Application</h1>

        <p class="lead">The application allows managing contacts. The application consists of a single web page displaying a list of all contacts (click menu "Contacts" right top),
allows to create a contact, delete a contact, edit a contact, delete all displayed contacts and filter/search contacts with
specific attributes.</p>

        <p><a class="btn btn-lg btn-success" href="http://localhost/yii/basic/web/index.php?r=contacts/contacts">Get started aplication "Contacts"</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Business Features</h2>

                <p>The section displays contacts in the list. Following is the information that is displayed for every contact:<br/>
<h4>Basic information:</h4>
<ul>
<li>First Name</li> 
<li>Last Name</li>
<li>Phone Number</li>
<li>Email</li>
<li>Address</li>
<li>City</li>
<li>Zip</li>
<li>Is Friend</li>
</ul>
.</p>
            </div>
            <div class="col-lg-4">
                <h2>Contacts handling</h2>

                <p>Following commands are available over each contact item:
                <ul>
                	<li>View		Click icon with eye right end of line with contact/li>
						<li>Edit		Click icon with pen right end of line with contact</li>     
						<li>Delete  Click icon with trash can right end of line with contact</li>                						           
                </ul>
						Filter contacts in each field by typing your key in field above needed record on top of the table.
						Sorting your contacts by clicking Title of needed record.					 
					 </p>
            </div>
            <div class="col-lg-4">
                <h2>Paging</h2>

                <p>All contacts displaing in table divided by 6. Page navigation is under left bottom corner of table with contacts.</p>


            </div>
        </div>

    </div>

</div>
